//Used by main to get the authenticateUser function
#ifndef AUTH_H
#define AUTH_H

void authenticateUser();

#endif